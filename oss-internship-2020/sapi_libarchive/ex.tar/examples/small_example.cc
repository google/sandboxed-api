#include <iostream>

#include <archive.h>
#include <archive_entry.h>

int main() {
    std::cout << "WORKS" << std::endl;
    return 0;
}