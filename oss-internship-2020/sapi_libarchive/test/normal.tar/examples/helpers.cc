
#include "helpers.h"

std::string MakeAbsolutePathAtCWD(std::string path) {
    std::string result =  sandbox2::file_util::fileops::MakeAbsolute(path, sandbox2::file_util::fileops::GetCWD());
    CHECK(result != "") << "Could not create absolute path for: " << path;
    return sandbox2::file::CleanPath(result);
}

std::vector<std::string> MakeAbsolutePathsVec(char *argv[]) {
  std::vector<std::string> arr;
  sandbox2::util::CharPtrArrToVecString(argv, &arr);
  // std::transform(arr.begin(), arr.end(), arr.begin(), [](std::string s) ->
  // std::string {
  //     return sandbox2::file_util::fileops::MakeAbsolute(s,
  //     sandbox2::file_util::fileops::GetCWD());
  // });
  std::transform(arr.begin(), arr.end(), arr.begin(), MakeAbsolutePathAtCWD);
  return arr;
}